<!--This allows us to create an "if statment " and then loop through them like in this exampel we have used php language to create the if statment that machs the posts, we have said if we have posts do this which the loop function that allows us to loop throgh all the posts -->
<!--The pretty basic concepts are the loop and the if statment and so on and so fourth-->




<?php

get_header();

if (have_posts()):
    while (have_posts()) : the_post(); ?>

	<article class="post">
	<div class="containerM">
		<h2>
			<a href="<?php the_permalink(); ?>">
				<?php the_title() ?>
			</a>
		</h2>
		<?php the_content() ?>
		<?php comments_template(); ?>
		</div>
	</article>

	<?php endwhile;

else:
    echo '<p> ingen post hittas </p>';

endif;

get_footer();

?>

