<footer class="site-footer">
	<div class="containerM">

		<p>
			<?php bloginfo('name'); ?> - &copy;
			<?php echo date('Y'); ?>
		</p>
	</div>

</footer>



<?php wp_footer() ?>


</body>

</html>
